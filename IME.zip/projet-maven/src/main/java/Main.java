import java.util.ArrayList;
import java.util.List;

import gov.nih.nlm.uts.webservice.AttributeDTO;
import gov.nih.nlm.uts.webservice.Psf;
import gov.nih.nlm.uts.webservice.UtsFault_Exception;
import gov.nih.nlm.uts.webservice.UtsWsContentController;
import gov.nih.nlm.uts.webservice.UtsWsContentControllerImplService;
import gov.nih.nlm.uts.webservice.UtsWsMetadataController;
import gov.nih.nlm.uts.webservice.UtsWsMetadataControllerImplService;
import gov.nih.nlm.uts.webservice.UtsWsSecurityController;
import gov.nih.nlm.uts.webservice.UtsWsSecurityControllerImplService;

public class Main {

	private static String ticketGrantingTicket;
	private static UtsWsSecurityController utsSecurityService;
	private static UtsWsMetadataController utsMetadataService;
	private static UtsWsContentController utsContentService;

	
	public static void main(String[] args) throws UtsFault_Exception {	
		//__________________________________________________________________________________________________________
		UtsWsSecurityController utsSecurityService = null;	
		try {
			 utsSecurityService = (new UtsWsSecurityControllerImplService()).getUtsWsSecurityControllerImplPort();
			 System.out.println(utsSecurityService);
			}
			catch (Exception e) {
			 System.out.println("Error!!!" + e.getMessage());
			}
		//_____________________________________________________________________________________________________________
		try {
			 utsMetadataService = (new UtsWsMetadataControllerImplService()).getUtsWsMetadataControllerImplPort();
			 }

			 catch (Exception e) {
			 System.out.println("Error!!!" + e.getMessage());
			 }
		
		//______________________________________________________________________________________________________________
		try {
			 utsContentService = (new UtsWsContentControllerImplService()).getUtsWsContentControllerImplPort();
			}

			catch (Exception e) {
			 System.out.println("Error!!!" + e.getMessage());
			}
		
		// Authentification 
		// Step 1 - Proxy Grant ticket
			String username = "deannawung";
			String password = "m2sitistermino#";
			
			try {
				ticketGrantingTicket = utsSecurityService.getProxyGrantTicket(username, password);
				System.out.println(ticketGrantingTicket);
			} catch (Exception e) {
				System.out.println("Ticket failed");
			}
	
		// Step 2 - Single use ticket 
			String serviceName = "http://umlsks.nlm.nih.gov";
			String singleTicket = "";
			
			try {
				singleTicket = getProxyTicket(ticketGrantingTicket, serviceName);
				System.out.println(singleTicket+"there is a single ticket");
			} catch (Exception e) {
				System.out.println("Single ticket failed");
			}

						
			List<AttributeDTO> attributes = new ArrayList<AttributeDTO>();
			Psf myPsf = new Psf();	
			String currentUmlsRelease = utsMetadataService.getCurrentUMLSVersion(singleTicket);
					
			do {
		    	 //attributes = utsContentService.getSourceDescriptorAttributes(singleTicket, currentUmlsRelease, "D006257", "MSH",myPsf);	
		    	 attributes = utsContentService.getSourceDescriptorAttributes(singleTicket, currentUmlsRelease, "C224", "CIM10",myPsf);
		    	
		    	 System.out.println("OK"+attributes);
		    	 for(AttributeDTO attribute:attributes) {
		    		 String atui = attribute.getUi();
		    		 String atn = attribute.getName();
		    		 String atv = attribute.getValue();
		    		 System.out.println("OK1");
		    		 System.out.println(atui+"|"+atn+"|"+atv);
		    	 }
		    	
		     }while (attributes.size() > 0);
			
			
			System.out.println(attributes.toString());
			System.out.println("done");
	}
	


	
	private static  String getProxyTicket(String ticketGrantingTicket2, String serviceName){	 
			 utsSecurityService = null;
			try {
				return utsSecurityService.getProxyTicket(ticketGrantingTicket, serviceName);
			} catch (Exception e) {
				return "";
			}
			 	 
	}

	
}
